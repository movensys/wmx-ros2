#include <stdio.h>
#include <string.h>
#include <unistd.h>  

char WMX3GetChar(char defValue)
{
    return getchar();
}

int WMX3Scanf(int *dst, int defValue)
{
    return scanf("%d", dst);
}

int GetKeyState(char ch){
	return 0;
}


