/*****************************************************************************/
/* FILE        : CheckReverseConnection.cpp                                  */
/* DESCRIPTION : Sample to check if input / output ports are connected in    */
/*               reverse                                                     */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "EcApi.h"
#include "WMX3Api.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace ecApi;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api           Wmx3Lib;
Ecat			  EcLib(&Wmx3Lib);
EcMasterInfo      MotorInfo;

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();
bool IsReverse();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    printf("Program Start\n");
    Sleep(1000);

    // Initialization of WMX 3 engine.
    Initialize();
    
    // Get MasterInfo.
    EcLib.GetMasterInfo(&MotorInfo);

    //-----------------------------------------------------
    // If the the connection of network is established, 
    // this master state should be stay in Op state.
    //-----------------------------------------------------
    if (MotorInfo.state != EcStateMachine::Op)
    {
        printf("MotorInfo State Error[%x]\n", MotorInfo.state);
        Finalize();
        Sleep(3000);
        return 1;
    }

    if(IsReverse())
    {
        printf("Warning!!!Reverse connection has been detected.\n");
    }
    else
    {
        printf("Normal connection.\n");
    }

    Finalize();
    printf("Program End\n");
    Sleep(3000);

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : IsReverse                                                   */
/* Description : Check whether the input port and the output port are        */
/*               connected in reverse.                                       */
/*---------------------------------------------------------------------------*/
bool IsReverse()
{
    for (unsigned int i = 0; i < MotorInfo.numOfSlaves; i++)
    {
        if (MotorInfo.slaves[i].reverseSlave == 1)
        {
            return true;
        }
    }

    return false;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("CheckReverseConnection");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
