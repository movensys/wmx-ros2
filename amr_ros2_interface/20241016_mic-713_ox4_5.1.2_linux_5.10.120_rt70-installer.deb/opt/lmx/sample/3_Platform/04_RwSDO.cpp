/*****************************************************************************/
/* FILE        : RwSDO.cpp                                                   */
/* DESCRIPTION : Use SDO to read and write the drive profile.                */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "EcApi.h"
#include "WMX3Api.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace ecApi;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
Ecat             EcLib(&Wmx3Lib);            
EcMasterInfo     MotorInfo;

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    printf("Program Start\n");

    Sleep(1000);

    // Initialization of WMX 3 engine.
    Initialize();
    
    // Get MasterInfo.
    EcLib.GetMasterInfo(&MotorInfo);

    //-----------------------------------------------------
    // If the the connection of network is established, 
    // this master state should be stay in Op state.
    //-----------------------------------------------------
    if (MotorInfo.state != EcStateMachine::Op)
    {
        printf("MotorInfo State Error[%x]\n", MotorInfo.state);
        Finalize();
        Sleep(3000);
        return 1;
    }

    //-------------------------------------------------------------------------
    // In this sample, access the drive profile area(0x6000 - 0x6FFF) of the  
    // motor driver (A5B series) made by panasonic and read and write         
    // MaxMotorSpeed.                                                         
    // This read / write operation can also be executed from the "Advanced Funcs"
    // tab of EtherCAT Network Configurator.                 
    //-------------------------------------------------------------------------
    const int     sdoBuffSize  = 4;                 // [in]  SDO buffer size
    int           slaveId      = 0;                 // [in]  Slave ID to download / upload SDO data
    int           index        = 0x6080;            // [in]  Index number of SDO
    int           subIndex     = 0x0000;            // [in]  Sub index number of SDO

    unsigned int  waitTime     = 3000;              // [in]  SDO Upload Process timeout time
    unsigned char sdoWriteBuff[sdoBuffSize] = {0};  // [in]  SDO write buffer
    int           writeSDOData = 0x1C;              // [in]  Write SDO data.

    unsigned int  errorCode    = 0;                 // [out] SDO Error code
    unsigned int  actualSize   = 0;                 // [out] Size of actually uploaded SDO data
    unsigned char sdoReadBuff[sdoBuffSize] = {0};   // [out] SDO read buffer
    int           readSDOData  = 0;                 // [out] Read SDO data.

    memcpy(&sdoWriteBuff[0], &writeSDOData, sdoBuffSize);

    // Start Download SDO
    EcLib.SdoDownload(slaveId, index, subIndex, sdoBuffSize, sdoWriteBuff, &errorCode, waitTime);

    // It loads and displays the written SDO data.
    EcLib.SdoUpload(slaveId,     index, subIndex, sdoBuffSize, 
                    sdoReadBuff, &actualSize, &errorCode, waitTime);

    printf("------------ SDO Data -----------------\n");
    printf("input\n");
    printf("  Slave ID       [%4d]\n"   ,slaveId);
    printf("  Index          [0x%04x]\n",index);
    printf("  SubIndex       [0x%04x]\n",subIndex);
    printf("  SDO Buffer Size[%4d]\n"   ,sdoBuffSize);

    printf("output\n");
    printf("  Actual Size    [%4d]\n"    ,actualSize);
    readSDOData = *( (int *)(sdoReadBuff));
    printf("  Read Data      [0x%08x]\n" ,readSDOData);
    printf("  Error  Code    [0x%08x]\n" ,errorCode);

    printf("Stop by entering Enter...\n");
    WMX3GetChar('\n');

    Finalize();
    printf("Program End\n");
    Sleep(3000);

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
                         DeviceType::DeviceTypeNormal,
                         INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("RwSDO");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}