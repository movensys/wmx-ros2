/*****************************************************************************/
/* FILE        : CheckCrcAndRxError.cpp                                      */
/* DESCRIPTION : A sample that checks the EtherCAT packet and outputs an     */
/*               error.                                                      */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "EcApi.h"
#include "WMX3Api.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Class                                                                     */
/*****************************************************************************/
class Register {

public :
    int            registerSize;
    unsigned short *port;
    unsigned char  *currentRegister;
    unsigned char  *lstRegister;

	Register(int registerSize, 
                   unsigned short port0, 
                   unsigned short port1 = 0x0000, 
                   unsigned short port2 = 0x0000, 
                   unsigned short port3 = 0x0000,
                   unsigned short port4 = 0x0000, 
                   unsigned short port5 = 0x0000, 
                   unsigned short port6 = 0x0000, 
                   unsigned short port7 = 0x0000);
    ~Register();
    void SaveCurrentRegister(void);
    bool IsErrorRegisterIncreasing(void);
};

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace ecApi;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
Ecat             EcLib(&Wmx3Lib);            
EcMasterInfo     MotorInfo;

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();
void ReadRegister(int slaveID, Register &stRegister);

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    int  cycleCount = 0;

    // Register 
    // -------------------- RegSize, Port1 , Port2 , Port3 , Port4,
    //                               Port5 , Port6 , Port7,  Port8
    Register  CrcRxFrmReg  (8,       0x0300, 0x0301, 0x0302, 0x0303,
                                     0x0304, 0x0305, 0x0306, 0x0307);

    Register  FwdRxErrReg  (4,       0x0308, 0x0309, 0x030A, 0x030B);
    Register  PUErrReg     (1,       0x030C);
    Register  LstLinkErrReg(4,       0x0310, 0x0311, 0x0312, 0x0313);

    printf("Program Start\n");
    Sleep(1000);

    // Initialization of WMX 3 engine.
    Initialize();
    
    // Get MasterInfo.
    EcLib.GetMasterInfo(&MotorInfo);

    //-----------------------------------------------------
    // If the the connection of network is established, 
    // this master state should be stay in Op state.
    //-----------------------------------------------------
    if (MotorInfo.state != EcStateMachine::Op)
    {
        printf("MotorInfo State Error[%x]\n", MotorInfo.state);
        Finalize();
        Sleep(3000);
        return 1;
    }
    
    while(1)
    {
        printf("Count:%6d\n", ++cycleCount);

        // --------------------------------------------------------
        // Saves the previous Register.
        // --------------------------------------------------------
        CrcRxFrmReg.SaveCurrentRegister();
        FwdRxErrReg.SaveCurrentRegister();
        PUErrReg.SaveCurrentRegister();
        LstLinkErrReg.SaveCurrentRegister();

        // --------------------------------------------------------
        // Read the data of each Register.
        // --------------------------------------------------------
        ReadRegister(0, CrcRxFrmReg);
        ReadRegister(0, FwdRxErrReg);
        ReadRegister(0, PUErrReg);
        ReadRegister(0, LstLinkErrReg);

        // --------------------------------------------------------
        // It checks whether an error has occurred in each Register.
        // --------------------------------------------------------
        printf("----------- Register Check Start (Hex Dump) ------\n");
        printf("CRC or RX Frame Err    : ");
        if(CrcRxFrmReg.IsErrorRegisterIncreasing())
        {
            printf(" Warning! There is CRC or RX Frame error in the network\n");
        }

        printf("Fwd RX  Err            : ");
        if(FwdRxErrReg.IsErrorRegisterIncreasing())
        {
            printf(" Warning! There is forward rx error in the network\n");
        }

        printf("Proccessing Unit Err   : ");
        if(PUErrReg.IsErrorRegisterIncreasing())
        {
            printf(" Warning! There is process unit error in the network\n");
        }

        printf("Lost Link Err          : ");
        if(LstLinkErrReg.IsErrorRegisterIncreasing())
        {
            printf(" Warning! There is link lost error in the network\n");
        }

        printf("----------- Register Check End   -----------------\n\n");

        if(GetKeyState('Q'))
        {
            printf("End...\n");
            break;
        }

        Sleep(1000);
    }

    Finalize();
    printf("Program End\n");
    Sleep(3000);

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : ReadRegister                                                */
/* Description : Read specified register.                                    */
/*---------------------------------------------------------------------------*/
void ReadRegister(int slaveID, Register &stRegister)
{
    //-------------------------------------------------------------------------
    // Read registers of the specified slave port.
    //-------------------------------------------------------------------------
    EcLib.RegisterRead(slaveID,
                  stRegister.port[0],
                  stRegister.registerSize, 
                  stRegister.currentRegister);
}

/*---------------------------------------------------------------------------*/
/* Function    : Register::Register                                          */
/* Description : Constructor of Register class.                              */
/*---------------------------------------------------------------------------*/
Register::Register(int registerSize, 
                   unsigned short port0, unsigned short port1, 
                   unsigned short port2, unsigned short port3,
                   unsigned short port4, unsigned short port5,
                   unsigned short port6, unsigned short port7)
{
    this->port          = new unsigned short[8];
    this->port[0]       = port0; this->port[1]       = port1;
    this->port[2]       = port2; this->port[3]       = port3;
    this->port[4]       = port4; this->port[5]       = port5;
    this->port[6]       = port6; this->port[7]       = port7;
    this->registerSize    = registerSize;
    this->currentRegister = new unsigned char[registerSize];
    this->lstRegister     = new unsigned char[registerSize];
    memset(this->currentRegister, 0x00, sizeof(unsigned char) * registerSize);
    memset(this->lstRegister,     0x00, sizeof(unsigned char) * registerSize);
}

/*---------------------------------------------------------------------------*/
/* Function    : Register::~Register                                         */
/* Description : Destructor of Register class.                               */
/*               (started when Register class is destroyed.)                 */
/*---------------------------------------------------------------------------*/
Register::~Register()
{
    delete this->currentRegister;
    delete this->lstRegister;
    delete this->port;
    this->currentRegister = NULL;
    this->lstRegister     = NULL;
    this->port            = NULL;
}

/*---------------------------------------------------------------------------*/
/* Function    : Register::SaveCurrentRegister                               */
/* Description : Saves the current Register.                                 */
/*---------------------------------------------------------------------------*/
void Register::SaveCurrentRegister(void)
{
    memcpy(this->lstRegister, this->currentRegister, 
           sizeof(unsigned char) * this->registerSize);
}

/*---------------------------------------------------------------------------*/
/* Function    : Register::IsErrorRegisterIncreasing                         */
/* Description : Compare with the previous Register, check if there is an    */
/*               error Register                                              */
/*---------------------------------------------------------------------------*/
bool Register::IsErrorRegisterIncreasing(void)
{
    bool ret = false;

    for(int i = 0; i < this->registerSize; i++)
    {
        printf("%02X ", this->currentRegister[i]);
 
        // --------------------------------------------------------------------
        // The user can check the error based on the Register data read in 
        // EcAPI -> ReadReg Method and judge whether to interrupt the communication.
        // --------------------------------------------------------------------
        if(this->currentRegister[i] != this->lstRegister[i])
        {
            ret = true;
        }
    }

    printf("\n");

    return ret;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
                         DeviceType::DeviceTypeNormal,
                         INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("CheckCrcAndRxError");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
