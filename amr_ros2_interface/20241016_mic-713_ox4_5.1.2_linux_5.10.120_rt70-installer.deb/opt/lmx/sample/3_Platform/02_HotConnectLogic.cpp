/*****************************************************************************/
/* FILE        : HotConnectLogic.cpp                                         */
/* DESCRIPTION : A sample confirming that communication with the driver is   */
/*               resumed by reconnecting even if the network is disconnected */
/*               while communicating with the driver.                        */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "EcApi.h"
#include "WMX3Api.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace ecApi;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
Ecat             EcLib(&Wmx3Lib);
EcMasterInfo     MotorInfo;

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();
bool IsAllAlive(bool &isLost);

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    int  cycleCount = 0;
    bool isLost;
    bool nowAlive  = false;
    bool prevAlive = true;

    printf("Program Start\n");

    Sleep(1000);

    // Initialization of WMX 3 engine.
    Initialize();
    
    // Get MasterInfo.
    EcLib.GetMasterInfo(&MotorInfo);

    //-----------------------------------------------------
    // If the the connection of network is established, 
    // this master state should be stay in Op state.
    //-----------------------------------------------------
    if (MotorInfo.state != EcStateMachine::Op)
    {
        printf("MotorInfo State Error[%x]\n", MotorInfo.state);
        Finalize();
        Sleep(3000);
        return 1;
    }

    printf("Press the Q key to exit...\n");
    while(1)
    {
        printf("Elapsed time[%4d]s : ",  ++cycleCount);

        // Check if all slaves are alive.
        nowAlive = IsAllAlive(isLost);
        if (nowAlive)
        {
            printf("All the slaves are alive.\n");
        }
        else
        {
            printf("One of the slave is not alive.\n");
        }

        // Resume communication when reconnection succeeds.
        if (isLost)
        {
            EcLib.StartHotconnect();
        }

        // Check slave revived.
        if(nowAlive && !prevAlive)
        {
            printf("Slave revived.\n");
            //-------------------------------------------------------
            // Since an amp alarm may occur on the Slave side, 
            // Please clear the amp alarm.
            //-------------------------------------------------------
        }
        
        prevAlive = nowAlive;
        Sleep(1000);

        if(GetKeyState('Q'))
        {
            printf("End...\n");
            break;
        }
    }

    Finalize();
    printf("Program End\n");
    Sleep(3000);

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : IsAllAlive                                                  */
/* Description : Check if all slaves are alive.                              */
/*---------------------------------------------------------------------------*/
bool IsAllAlive(bool &isLost)
{
    bool  bRet = true;

    EcLib.GetMasterInfo(&MotorInfo);

    // Check Slave alive.
    isLost = false;
    for (unsigned int i = 0; i < MotorInfo.numOfSlaves; i++)
    {
        if (MotorInfo.slaves[i].state != EcStateMachine::Op)
        {
            bRet = false;

            // Check Slave lost. 
            if ( (MotorInfo.slaves[i].state == EcStateMachine::None) ||
                 (MotorInfo.slaves[i].state == EcStateMachine::Init)   )
            {
                isLost = true;
            }
        }
    }

    return bRet;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
                         DeviceType::DeviceTypeNormal,
                         INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("HotConnectLogic");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}