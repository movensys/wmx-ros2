/*****************************************************************************/
/* FILE        : EventMotion.cpp                                             */
/* DESCRIPTION : Sample to execute PosCommand with IO bit as input.          */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "EventApi.h"
#include "IOApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);
Io               Wmx3Lib_io(&Wmx3Lib);
EventControl     Wmx3Lib_evt(&Wmx3Lib);
CoreMotionStatus CmStatus;

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    EventControl::Event  posEvent   = EventControl::Event();
    EventControl::Event::OutputFunctionArguments::StartSinglePos singlePos  = 
        EventControl::Event::OutputFunctionArguments::StartSinglePos();
    int posEventID = 1;

    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    Wmx3Lib_io.SetOutBit(0, 0, 0);

    //----------------------------------------------------------------------------
    // Register event contents (StartSinglePos).
    //----------------------------------------------------------------------------
    posEvent.enabled                  = 1;
    posEvent.inputFunction            = EventControl::EventInputFunction::IOBit;
    posEvent.input.ioBit.byteAddress  = 0;
    posEvent.input.ioBit.bitAddress   = 0;
    posEvent.input.ioBit.invert       = 0;
    posEvent.input.ioBit.ioSourceType = IOSourceType::Output;

    posEvent.outputFunction        = EventControl::EventOutputFunction::StartSinglePos;
    singlePos.axis                 = 0;
    singlePos.type                 = ProfileType::Trapezoidal;
    singlePos.target               = 500000;
    singlePos.velocity             = 100000;
    singlePos.acc                  = 1000000;
    singlePos.dec                  = 1000000;

    posEvent.output.startSinglePos = singlePos;

    //----------------------------------------------------------------------------
    // Set events.
    //----------------------------------------------------------------------------
    Wmx3Lib_evt.SetEvent(&posEventID, &posEvent);

    printf("Event Wait...\n");
    Sleep(3000);

    //----------------------------------------------------------------------------
    // Set bit which is an event occurrence condition.
    //----------------------------------------------------------------------------
    printf("Set OutBit.\n");
    Wmx3Lib_io.SetOutBit(0, 0, 1);
	Sleep(100);
    Wmx3Lib_cm.motion->Wait(0);
    printf("Completed!\n");

    Wmx3Lib_evt.ClearAllEvent();
    Wmx3Lib_io.SetOutBit(0, 0, 0);

    Finalize();
    printf("Program End\n");
    Sleep(3000);

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("EventMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);

    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
