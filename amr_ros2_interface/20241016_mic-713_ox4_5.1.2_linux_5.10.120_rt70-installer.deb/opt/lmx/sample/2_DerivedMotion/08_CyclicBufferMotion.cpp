/*****************************************************************************/
/* FILE        : CyclicBufferMotion.cpp                                      */
/* DESCRIPTION : Sample to move to the specified position after a specified  */
/*               cycle time using CyclicBuffer                               */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "CyclicBufferApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);
CyclicBuffer     Wmx3Lib_cyc(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    CyclicBufferSingleAxisCommand cyclicBufferSingleAxisCommand = CyclicBufferSingleAxisCommand();

    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    // Open cyclic buffer of specified axis
    Wmx3Lib_cyc.OpenCyclicBuffer(0, 1024);

    // Set axis movement type (absolute / relative)
    cyclicBufferSingleAxisCommand.type = CyclicBufferCommandType::RelativePos;

    // Execute cyclic buffer of specified axis
    Wmx3Lib_cyc.Execute(0);

    //-------------------------------------------------------------------------
    // Dynamically add points
    //-------------------------------------------------------------------------
    // Move in the positive direction
    cyclicBufferSingleAxisCommand.intervalCycles = 200; 
    cyclicBufferSingleAxisCommand.command = 10000;
    Wmx3Lib_cyc.AddCommand(0, &cyclicBufferSingleAxisCommand);

    // Stop for a certain period of time
    cyclicBufferSingleAxisCommand.intervalCycles = 600;
    cyclicBufferSingleAxisCommand.command = 0;
    Wmx3Lib_cyc.AddCommand(0, &cyclicBufferSingleAxisCommand);

    // Move to original position
    cyclicBufferSingleAxisCommand.intervalCycles = 200;
    cyclicBufferSingleAxisCommand.command = -10000;
    Wmx3Lib_cyc.AddCommand(0, &cyclicBufferSingleAxisCommand);

    //Wait until the motion is over
    Sleep(1500);

    // Close cyclic buffer of specified axis
    Wmx3Lib_cyc.CloseCyclicBuffer(0);

    Finalize();

    printf("Program End\n");
    Sleep(3000);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ To servo-on completion.                   */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("CyclicBufferMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);

    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    //Homing
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);

    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}