/*****************************************************************************/
/* FILE        : CompensationMotion.cpp                                      */
/* DESCRIPTION : Sample for correcting axis position from one dimensional    */
/*               offset value and two dimensional offset value.              */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "CompensationApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Define                                                                    */
/*****************************************************************************/
#define DEVICE_NAME   "CompensationMotion"
#define MOTOR_X  0
#define MOTOR_Y  1
#define MOTOR_Z  2

#define CHANNEL_1 0
#define CHANNEL_2 1
#define CHANNEL_3 2

#define COMP_X_COUNT    10
#define COMP_X_INTERVAL 10000
#define COMP_Y_COUNT    10
#define COMP_Y_INTERVAL 10000

enum class SeqStatus 
{
    SEQ_INIT,
    START_HOME,
    MOTION_START,
    MOTION_STOP,
    SEQ_ERROR,
    SEQ_END
};

enum class CompMode
{
    ONE_D_X,
    TWO_D_XY,
    TWO_D_Z,
    THREE_D_XYZ,
};

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
//                                   0,  1,  2,  3,  4,  5,  6,   7,  8,  9
double XCompData[COMP_X_COUNT] = { -10, 12,  9, -7, -3, -1,  3,  12,  8,  0 };

double XTwoDCompData[COMP_X_COUNT][COMP_Y_COUNT] = {
//      0,  1,  2,  3,  4,  5,  6,   7,  8,  9
    { -10, 12,  9, -7, -3, -1,  3,  12,  8,  0}, // 0
    {   7,  9,  9, -7, -3,  8,  3,  12,  8,  0}, // 1
    {   2,  3,  9, -7, -3, -1,  3,  12,  8,  2}, // 2
    {   6, -1,  5,  1, -3,  0,  3,   8,  8, -3}, // 3
    {  -9, 12,  9, -7, -3, -1,  3,  12,  9,  8}, // 4
    {  -3, 12,  2, -7,  9, -1,  3,  12,  8,  7}, // 5
    {   2, 12,  9, -7, -3, -1,  3,  12,  8, -5}, // 6
    {   8, 12, -6,  2, -3, -1,  3,  12,  8,  4}, // 7
    {  -5, 12, -5, -7, -3, -1,  3,  12,  8, -3}, // 8
    {  -4, 12,  9, -7, -3, -1,  3,  12,  8,  6}, // 9
};

double YTwoDCompData[COMP_X_COUNT][COMP_Y_COUNT] = {
//      0,  1,  2,  3,  4,  5,  6,   7,  8,  9
    {   7,  9,  9, -7, -3,  8,  3,  12,  8,  0}, // 0
    {  -5, 12, -5, -7, -3, -1,  3,  12,  8, -3}, // 1
    {   2,  3,  9, -7, -3, -1,  3,  12,  8,  2}, // 2
    {   6, -1,  5,  1, -3,  0,  3,   8,  8, -3}, // 3
    {  -9, 12,  9, -7, -3, -1,  3,  12,  9,  8}, // 4
    {   2, 12,  9, -7, -3, -1,  3,  12,  8, -5}, // 5
    { -10, 12,  9, -7, -3, -1,  3,  12,  8,  0}, // 6
    {   8, 12, -6,  2, -3, -1,  3,  12,  8,  4}, // 7
    {  -3, 12,  2, -7,  9, -1,  3,  12,  8,  7}, // 8
    {  -4, 12,  9, -7, -3, -1,  3,  12,  8,  6}  // 9
};

double ZTwoDCompData[COMP_X_COUNT][COMP_Y_COUNT] = {
//      0,  1,  2,  3,  4,  5,  6,   7,  8,  9
    {  -3, 12,  2, -7,  9, -1,  3,  12,  8,  7}, // 0
    {   6, -1,  5,  1, -3,  0,  3,   8,  8, -3}, // 1
    {   2,  3,  9, -7, -3, -1,  3,  12,  8,  2}, // 2
    {  -4, 12,  9, -7, -3, -1,  3,  12,  8,  6}, // 3
    {  -9, 12,  9, -7, -3, -1,  3,  12,  9,  8}, // 4
    {  -5, 12, -5, -7, -3, -1,  3,  12,  8, -3}, // 5
    {   2, 12,  9, -7, -3, -1,  3,  12,  8, -5}, // 6
    { -10, 12,  9, -7, -3, -1,  3,  12,  8,  0}, // 7
    {   7,  9,  9, -7, -3,  8,  3,  12,  8,  0}, // 8
    {   8, 12, -6,  2, -3, -1,  3,  12,  8,  4}, // 9
};

WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);
Compensation     Wmx3Lib_comp(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
bool CreateWMX3Device(WMX3Api &device, const char *devName);
bool StartComWMX3Device(WMX3Api &device);
void CloseWMX3Device(WMX3Api &device);
void StartPosCmd(int axis, double target);

void Set1DCompensation(PitchErrorCompensationData &oneDCompData);
void Set2DCompensation_ForXY (TwoDPitchErrorCompensationData &twoDCompDataX, 
                              TwoDPitchErrorCompensationData &twoDCompDataY);
void Set2DCompensation_ForZ  (TwoDPitchErrorCompensationData &twoDCompDataZ);
void Set3DCompensation_ForXYZ(TwoDPitchErrorCompensationData &twoDCompDataX,
                              TwoDPitchErrorCompensationData &twoDCompDataY,
                              TwoDPitchErrorCompensationData &twoDCompDataZ);

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    int                iRet;
    bool               bRet;
    bool               SeqRunning = true;
    char               errString[256];
    CompMode           selectCompMode;

    PitchErrorCompensationData     oneDCompData;
    TwoDPitchErrorCompensationData twoDCompDataX;
    TwoDPitchErrorCompensationData twoDCompDataY;
    TwoDPitchErrorCompensationData twoDCompDataZ;

    printf("Program Start\n");
    Sleep(1000);

    SeqStatus SeqState = SeqStatus::SEQ_INIT;
    
    while(SeqRunning)
    {
        // Get servo status.
        if(SeqState != SeqStatus::SEQ_INIT)
        {
            Wmx3Lib_cm.GetStatus(&CmStatus);
        }
        
        switch(SeqState)
        {

        // Initialization of WMX 3 engine and servo.
        case SeqStatus::SEQ_INIT:

            // Create device.
            bRet = CreateWMX3Device(Wmx3Lib, DEVICE_NAME);
            if(!bRet)
            {
                SeqState = SeqStatus::SEQ_ERROR;
                break;
            }

            // Start communications.
            bRet = StartComWMX3Device(Wmx3Lib);
            if(!bRet)
            {
                SeqState = SeqStatus::SEQ_ERROR;
                break;
            }

            // Get WMX3 engine status.
            iRet = Wmx3Lib_cm.GetStatus(&CmStatus);
            if(iRet != ErrorCode::None)
            {
                Wmx3Lib_cm.ErrorToString(iRet, errString, 256);
                printf("GetStatus Error! [%s]\n", errString);
                SeqState = SeqStatus::SEQ_ERROR;
                break;
            }

            // Servo On.
            Wmx3Lib_cm.axisControl->SetServoOn(MOTOR_X, 1);
            Wmx3Lib_cm.axisControl->SetServoOn(MOTOR_Y, 1);
            Wmx3Lib_cm.axisControl->SetServoOn(MOTOR_Z, 1);

            // Check servo-ON servo.
            while( (!CmStatus.axesStatus[MOTOR_X].servoOn) ||
                   (!CmStatus.axesStatus[MOTOR_Y].servoOn) ||
                   (!CmStatus.axesStatus[MOTOR_Z].servoOn)   )
            {
                Wmx3Lib_cm.GetStatus(&CmStatus);
                Sleep(10);
            }

            SeqState = SeqStatus::START_HOME;
            break;

        // Homing the servo to the home position.
        case SeqStatus::START_HOME :

            Wmx3Lib_cm.axisControl->SetAxisCommandMode(MOTOR_X, AxisCommandMode::Position);
            Wmx3Lib_cm.axisControl->SetAxisCommandMode(MOTOR_Y, AxisCommandMode::Position);
            Wmx3Lib_cm.axisControl->SetAxisCommandMode(MOTOR_Z, AxisCommandMode::Position);

            Wmx3Lib_cm.home->StartHome(MOTOR_X);
            Wmx3Lib_cm.home->StartHome(MOTOR_Y);
            Wmx3Lib_cm.home->StartHome(MOTOR_Z);

            // Check whether the servo's homing is completed.
            while( (!CmStatus.axesStatus[MOTOR_X].homeDone) || 
                   (!CmStatus.axesStatus[MOTOR_Y].homeDone) || 
                   (!CmStatus.axesStatus[MOTOR_Z].homeDone)   )
            {
                Wmx3Lib_cm.GetStatus(&CmStatus);
                Sleep(10);
            }
            SeqState = SeqStatus::MOTION_START;
            break;

        // Move the servo axis to the target position.
        case SeqStatus::MOTION_START:

            // Move the axis to the specified position.
            StartPosCmd(MOTOR_X, 20000);
            StartPosCmd(MOTOR_Y, 25000);
            StartPosCmd(MOTOR_Z, 40000);

            //-----------------------------------------------------------------
            // Start compensation.
            //-----------------------------------------------------------------
            // Select compensation type.
            selectCompMode = CompMode::ONE_D_X;

            switch(selectCompMode)
            {
                // One-dimensional compensation of X axis.
                case CompMode::ONE_D_X     :
                    // Pitch error compensation data is set on the X axis.
                    Set1DCompensation(oneDCompData);
                    Wmx3Lib_comp.SetPitchErrorCompensation(MOTOR_X, &oneDCompData);
                    Wmx3Lib_comp.EnablePitchErrorCompensation(MOTOR_X);
                    break;

                // Two-dimensional compensation of X axis, Y axis.
                case CompMode::TWO_D_XY    :
                    // X, Y-axis pitch error compensation data is set to channel1, channel2. 
                    Set2DCompensation_ForXY(twoDCompDataX, twoDCompDataY);
                    Wmx3Lib_comp.Set2DPitchErrorCompensation(CHANNEL_1, &twoDCompDataX);
                    Wmx3Lib_comp.Set2DPitchErrorCompensation(CHANNEL_2, &twoDCompDataY);
                    Wmx3Lib_comp.Enable2DPitchErrorCompensation(CHANNEL_1);
                    Wmx3Lib_comp.Enable2DPitchErrorCompensation(CHANNEL_2);
                    break;

                // Two-dimensional compensation of Z axis.
                case CompMode::TWO_D_Z     :
                    // Z-axis pitch error compensation data is set to channel 1.
                    Set2DCompensation_ForZ(twoDCompDataZ);
                    Wmx3Lib_comp.Set2DPitchErrorCompensation(CHANNEL_1, &twoDCompDataZ);
                    Wmx3Lib_comp.Enable2DPitchErrorCompensation(CHANNEL_1);
                    break;

                // Two-dimensional compensation of X axis, Y axis, Z axis.
                case CompMode::THREE_D_XYZ :
                    // X, Y, Z-axis pitch error compensation data is set to 
                    // channel 1, channel2, channel3.
                    Set3DCompensation_ForXYZ(twoDCompDataX, twoDCompDataY, twoDCompDataZ);
                    Wmx3Lib_comp.Set2DPitchErrorCompensation(CHANNEL_1, &twoDCompDataX);
                    Wmx3Lib_comp.Set2DPitchErrorCompensation(CHANNEL_2, &twoDCompDataY);
                    Wmx3Lib_comp.Set2DPitchErrorCompensation(CHANNEL_3, &twoDCompDataZ);
                    Wmx3Lib_comp.Enable2DPitchErrorCompensation(CHANNEL_1);
                    Wmx3Lib_comp.Enable2DPitchErrorCompensation(CHANNEL_2);
                    Wmx3Lib_comp.Enable2DPitchErrorCompensation(CHANNEL_3);
                    break;
            }

            printf("Wait for Enter key (Stop with enter key input).\n");
            WMX3GetChar('\n');

            SeqState = SeqStatus::MOTION_STOP;
            break;

        // Stop the servo.
        case SeqStatus::MOTION_STOP :

            // Stop the master axis.
            Wmx3Lib_cm.motion->ExecQuickStop(MOTOR_X);
            Wmx3Lib_cm.motion->ExecQuickStop(MOTOR_Y);
            Wmx3Lib_cm.motion->ExecQuickStop(MOTOR_Z);
            printf("Stop Completed.\n");
            Sleep(4000);
            SeqState = SeqStatus::SEQ_END;
            break;

        // Error handling.
        case SeqStatus::SEQ_ERROR :

            printf("WMX SEQ Error\r\n");
            Sleep(100);
            SeqState = SeqStatus::SEQ_END;
            break;

        // End processing.
        case SeqStatus::SEQ_END :

            CloseWMX3Device(Wmx3Lib);
            printf("Program End\n");
            Sleep(3000);

            SeqRunning = false;
            break;
        }
    }

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Set1DCompensation                                           */
/* Description : Set one-dimensional compensation data on X axis.            */
/*---------------------------------------------------------------------------*/
void Set1DCompensation(PitchErrorCompensationData &oneDCompData)
{
    oneDCompData = PitchErrorCompensationData();
    oneDCompData.enable            = 1;
    oneDCompData.pitchOriginIndex  = 2; //Based on the current position value of axis, the variable should be different.
    oneDCompData.pitchCount    = COMP_X_COUNT;
    oneDCompData.pitchInterval = COMP_X_INTERVAL;
    memcpy(&oneDCompData.pitchCompensationValue,
           &XCompData,
           sizeof(XCompData));
}

/*---------------------------------------------------------------------------*/
/* Function    : Set2DCompensation_ForXY                                     */
/* Description : Set two-dimensional correction data on X axis and           */
/*               Y axis respectively.                                        */
/*---------------------------------------------------------------------------*/
void Set2DCompensation_ForXY(TwoDPitchErrorCompensationData &twoDCompDataX, 
                             TwoDPitchErrorCompensationData &twoDCompDataY)
{
    twoDCompDataX.axis = MOTOR_X;
    twoDCompDataX.pitchCount[0]    = COMP_X_COUNT;
    twoDCompDataX.pitchCount[1]    = COMP_Y_COUNT;
    twoDCompDataX.pitchInterval[0] = COMP_X_INTERVAL;
    twoDCompDataX.pitchInterval[1] = COMP_Y_INTERVAL;
    twoDCompDataX.pitchOriginIndex[0]   = 2; //Based on the current position value of axis, the variable should be different.
    twoDCompDataX.pitchOriginIndex[1]   = 5; //Based on the current position value of axis, the variable should be different.
    twoDCompDataX.referenceAxis[0] = MOTOR_X;
    twoDCompDataX.referenceAxis[1] = MOTOR_Y;

    for (int i = 0; i < COMP_X_COUNT; i++)
    {
        memcpy(&twoDCompDataX.pitchCompensationValue[i],
            &XTwoDCompData[i],
            sizeof(XTwoDCompData[i]));
    }

    twoDCompDataY.axis = MOTOR_Y;
    twoDCompDataY.pitchCount[0]    = COMP_X_COUNT;
    twoDCompDataY.pitchCount[1]    = COMP_Y_COUNT;
    twoDCompDataY.pitchInterval[0] = COMP_X_INTERVAL;
    twoDCompDataY.pitchInterval[1] = COMP_Y_INTERVAL;
    twoDCompDataY.pitchOriginIndex[0]   = 2; //Based on the current position value of axis, the variable should be different.
    twoDCompDataY.pitchOriginIndex[1]   = 5; //Based on the current position value of axis, the variable should be different.
    twoDCompDataY.referenceAxis[0] = MOTOR_X;
    twoDCompDataY.referenceAxis[1] = MOTOR_Y;

    for (int i = 0; i < COMP_X_COUNT; i++)
    {
        memcpy(&twoDCompDataY.pitchCompensationValue[i],
            &YTwoDCompData[i],
            sizeof(YTwoDCompData[i]));
    }
}

/*---------------------------------------------------------------------------*/
/* Function    : Set2DCompensation_ForZ                                      */
/* Description : Set two-dimensional compensation data on Z axis.            */
/*---------------------------------------------------------------------------*/
void Set2DCompensation_ForZ(TwoDPitchErrorCompensationData &twoDCompDataZ)
{
    twoDCompDataZ.axis = MOTOR_Z;
    twoDCompDataZ.pitchCount[0]    = COMP_X_COUNT;
    twoDCompDataZ.pitchCount[1]    = COMP_Y_COUNT;
    twoDCompDataZ.pitchInterval[0] = COMP_X_INTERVAL;
    twoDCompDataZ.pitchInterval[1] = COMP_Y_INTERVAL;
    twoDCompDataZ.pitchOriginIndex[0]   = 1; //Based on the current position value of axis, the variable should be different.
    twoDCompDataZ.pitchOriginIndex[1]   = 3; //Based on the current position value of axis, the variable should be different.
    twoDCompDataZ.referenceAxis[0] = MOTOR_X;
    twoDCompDataZ.referenceAxis[1] = MOTOR_Y;

    for (int i = 0; i < COMP_X_COUNT; i++)
    {
        memcpy(&twoDCompDataZ.pitchCompensationValue[i],
            &ZTwoDCompData[i],
            sizeof(ZTwoDCompData[i]));
    }
}

/*---------------------------------------------------------------------------*/
/* Function    : Set3DCompensation_ForXYZ                                    */
/* Description : Set two-dimensional correction data on X axis and           */
/*               Y axis and Z axis respectively.                             */
/*---------------------------------------------------------------------------*/
void Set3DCompensation_ForXYZ(TwoDPitchErrorCompensationData &twoDCompDataX,
                              TwoDPitchErrorCompensationData &twoDCompDataY,
                              TwoDPitchErrorCompensationData &twoDCompDataZ)
{
    Set2DCompensation_ForXY(twoDCompDataX, twoDCompDataY);
    Set2DCompensation_ForZ(twoDCompDataZ);
}

/*---------------------------------------------------------------------------*/
/* Function    : StartPosCmd                                                 */
/* Description : Move the specified axis to the specified position.          */
/*---------------------------------------------------------------------------*/
void StartPosCmd(int axis, double target)
{
    Motion::PosCommand posCommand; 

    posCommand = Motion::PosCommand();
    posCommand.profile.type             = ProfileType::Trapezoidal;
    posCommand.axis                     = axis;
    posCommand.target                   = target;
    posCommand.profile.velocity         = 500000;
    posCommand.profile.acc              = 1000000;
    posCommand.profile.dec              = 1000000;
            
    Wmx3Lib_cm.motion->StartMov(&posCommand);
}

/*---------------------------------------------------------------------------*/
/* Function    : CreateWMX3Device                                            */
/* Description : Creates a device with the specified device Name.            */
/*---------------------------------------------------------------------------*/
bool CreateWMX3Device(WMX3Api &device, const char *devName)
{
    char devicePath[] = {"/opt/lmx/"}; 

    device.CreateDevice(devicePath, DeviceType::DeviceTypeNormal,
                        INFINITE);

    // Set Device Name.
    device.SetDeviceName(devName);
    return true;  
}

/*---------------------------------------------------------------------------*/
/* Function    : StartComWMX3Device                                          */
/* Description : Communication with the specified device is started.         */
/*---------------------------------------------------------------------------*/
bool StartComWMX3Device(WMX3Api &device)
{
    int  ret;

    ret = device.StartCommunication(INFINITE);
    if (ret != (int)ErrorCode::None)
    {
        return false;
    }

    return true;
}

/*---------------------------------------------------------------------------*/
/* Function    : CloseWMX3Device                                             */
/* Description : Discard the device.                                         */
/*---------------------------------------------------------------------------*/
void CloseWMX3Device(WMX3Api &device)
{
    // Stop Communications.
    device.StopCommunication(INFINITE);

    // Discard the device.
    device.CloseDevice();
}
