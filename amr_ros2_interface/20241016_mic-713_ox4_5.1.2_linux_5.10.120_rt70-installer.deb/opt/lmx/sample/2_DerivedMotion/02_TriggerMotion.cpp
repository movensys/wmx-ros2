/*****************************************************************************/
/* FILE        : TriggerMotion.cpp                                           */
/* DESCRIPTION : Sample to set the trigger and move the axis.                */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    // Move the motor to the specified position.
	Motion::PosCommand posCommand = Motion::PosCommand();
    posCommand.profile.type             = ProfileType::Trapezoidal;
    posCommand.axis                     = 0;
    posCommand.target                   = 500000;
    posCommand.profile.velocity         = 100000;
    posCommand.profile.acc              = 1000000;
    posCommand.profile.dec              = 1000000;

    Wmx3Lib_cm.motion->StartMov(&posCommand);

    // Execute "command with trigger".
	Motion::TriggerPosCommand tgrPosCommand = Motion::TriggerPosCommand();
    tgrPosCommand.profile.type             = ProfileType::Trapezoidal;
    tgrPosCommand.axis                     = 1;
    tgrPosCommand.target                   = 500000;
    tgrPosCommand.profile.velocity         = 100000;
    tgrPosCommand.profile.acc              = 1000000;
    tgrPosCommand.profile.dec              = 1000000;
    
    //----------------------------------------------------------------------------
    // Create Trigger.
    // ->Start when the remaining distance of 0 axis reaches 10000 pulse.
    //----------------------------------------------------------------------------
	Trigger trigger = Trigger();
    trigger.triggerAxis   = 0;
    trigger.triggerType   = TriggerType::RemainingDistance;
    trigger.triggerValue  = 10000;
    tgrPosCommand.trigger = trigger;

    Wmx3Lib_cm.motion->StartMov(&tgrPosCommand);

    // Wait for the 0 axis to run.
	Motion::WaitCondition waitCondition = Motion::WaitCondition();
    waitCondition.axisCount         = 1;
    waitCondition.axis[0]           = 0;
    waitCondition.waitConditionType = Motion::WaitConditionType::MotionStarted;
    Wmx3Lib_cm.motion->Wait(&waitCondition);

    // Wait for 0 axis and 1 axis to stop.
    Wmx3Lib_cm.motion->Wait(0);
    Wmx3Lib_cm.motion->Wait(1);

    Finalize();
    printf("Program End\n");
    Sleep(3000);

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
                         DeviceType::DeviceTypeNormal,
                         INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("TriggerMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 1);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn && CmStatus.axesStatus[1].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    for(int i = 0; i < 2; i++)
    {
        Config::HomeParam homeParam;
        Wmx3Lib_cm.config->GetHomeParam(i, &homeParam);
        homeParam.homeType = Config::HomeType::CurrentPos;
        Wmx3Lib_cm.config->SetHomeParam(i, &homeParam);
        Wmx3Lib_cm.home->StartHome(i);
    }

    Wmx3Lib_cm.motion->Wait(0);
    Wmx3Lib_cm.motion->Wait(1);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn && !CmStatus.axesStatus[1].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
