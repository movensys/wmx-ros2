/*****************************************************************************/
/* FILE        : SplineMotion.cpp                                            */
/* DESCRIPTION : executes a simple total time type cubic spline with 9       */
/*               points.                                                     */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "AdvancedMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);
AdvancedMotion   Wmx3Lib_Adv(&Wmx3Lib);


/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    // Create the spline channel buffer
	Wmx3Lib_Adv.advMotion->CreateSplineBuffer(0, 100);

	AdvMotion::TotalTimeSplineCommand splineCommand = AdvMotion::TotalTimeSplineCommand();
    splineCommand.dimensionCount = 2;
    splineCommand.axis[0] = 0;
    splineCommand.axis[1] = 1;
    splineCommand.totalTimeMilliseconds = 1000;

    //Set the spline point data
	AdvMotion::SplinePoint splinePoint[9];

    Wmx3Lib_cm.GetStatus(&CmStatus);

    splinePoint[0].pos[0] = CmStatus.axesStatus[0].posCmd;
    splinePoint[0].pos[1] = CmStatus.axesStatus[1].posCmd;

    splinePoint[1].pos[0] = 10000;
    splinePoint[1].pos[1] = 0;

    splinePoint[2].pos[0] = 5000;
    splinePoint[2].pos[1] = 5000;

    splinePoint[3].pos[0] = 10000;
    splinePoint[3].pos[1] = 10000;

    splinePoint[4].pos[0] = 10000;
    splinePoint[4].pos[1] = 15000;

    splinePoint[5].pos[0] = 0;
    splinePoint[5].pos[1] = 15000;

    splinePoint[6].pos[0] = 0;
    splinePoint[6].pos[1] = 10000;

    splinePoint[7].pos[0] = 5000;
    splinePoint[7].pos[1] = 5000;

    splinePoint[8].pos[0] = 0;
    splinePoint[8].pos[1] = 0;

    //Execute the spline command
	Wmx3Lib_Adv.advMotion->StartCSplinePos(0, &splineCommand, 9, splinePoint);
    Wmx3Lib_cm.motion->Wait(0);
    Wmx3Lib_cm.motion->Wait(1);

    Finalize();

    printf("Program End\n");
    Sleep(3000);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("SplineMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 1);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn && CmStatus.axesStatus[1].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    //Homing
    for (int i = 0; i < 2; i++)
    {
        Config::HomeParam homeParam;
        Wmx3Lib_cm.config->GetHomeParam(i, &homeParam);
        homeParam.homeType = Config::HomeType::CurrentPos;
        Wmx3Lib_cm.config->SetHomeParam(i, &homeParam);
        Wmx3Lib_cm.home->StartHome(i);
        Wmx3Lib_cm.motion->Wait(i);
    }
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn && !CmStatus.axesStatus[1].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}