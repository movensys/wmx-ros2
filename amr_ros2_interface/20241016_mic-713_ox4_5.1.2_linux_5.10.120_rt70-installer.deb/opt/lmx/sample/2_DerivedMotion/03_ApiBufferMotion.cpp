/*****************************************************************************/
/* FILE        : ApiBufferMotion.cpp                                         */
/* DESCRIPTION : Sample to run after accumulating motion in ApiBuffer.       */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "ApiBufferApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);
CoreMotionStatus CmStatus;
ApiBuffer        Wmx3Lib_buf(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    printf("Program Start\n");
    Sleep(1000);

    Initialize();
    Wmx3Lib_buf = ApiBuffer(&Wmx3Lib);

    // Clear the buffer of the specified channel.
    Wmx3Lib_buf.Clear(0);

    // Create a buffer for the specified channel.
    Wmx3Lib_buf.CreateApiBuffer(0, 1024 * 1024 * 3);

    printf("Start Recording. \n");
    //---------------------------------------------------------
    // Start recording for the specified channel.
    Wmx3Lib_buf.StartRecordBufferChannel(0);

    // Move the motor to the specified position.
    Motion::PosCommand posCommand       = Motion::PosCommand();
    posCommand.profile.type             = ProfileType::Trapezoidal;
    posCommand.axis                     = 0;
    posCommand.target                   = 500000;
    posCommand.profile.velocity         = 200000;
    posCommand.profile.acc              = 2000000;
    posCommand.profile.dec              = 2000000;

    Wmx3Lib_cm.motion->StartPos(&posCommand);

    // Wait until the 0 axis finishes moving.
    Wmx3Lib_buf.Wait(0);

    // Return to the original position at half speed.
    posCommand.profile.velocity = 100000;
    posCommand.profile.acc      = 1000000;
    posCommand.profile.dec      = 1000000;
    posCommand.target           = 0;

    Wmx3Lib_cm.motion->StartPos(&posCommand);
    
    // Wait until the 0 axis finishes moving.
    Wmx3Lib_buf.Wait(0);

    // End Recording.
    Wmx3Lib_buf.EndRecordBufferChannel();
    //---------------------------------------------------------
    printf("End Recording. (It will run in 5 seconds.)\n");

    // Wait time.
    Sleep(5000);

    // Drive the motion accumulated in the buffer so far.
    printf("ApiBuffer -> Execute.\n");
    Wmx3Lib_buf.Execute(0);

    //Wait for axis movement to complete.
    Wmx3Lib_cm.motion->Wait(0);

    // Destroy API buffer resources.
    Wmx3Lib_buf.Halt(0);
    Wmx3Lib_buf.FreeApiBuffer(0);

    Finalize();
    printf("Program End\n");
    Sleep(3000);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("ApiBufferMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);

    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
