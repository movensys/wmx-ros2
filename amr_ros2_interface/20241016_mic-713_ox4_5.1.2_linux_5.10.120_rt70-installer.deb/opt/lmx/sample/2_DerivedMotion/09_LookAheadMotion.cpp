/*****************************************************************************/
/* FILE        : LookAheadMotion.cpp                                         */
/* DESCRIPTION : Samples that perform path interporation with look ahead.    */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "AdvancedMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);
AdvancedMotion   Wmx3Lib_Adv(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    // LookAhead Start --------------------------------------------------------
    printf("LookAhead Interpolation\n");

    // Create LookAhead Buffer.
    Wmx3Lib_Adv.advMotion->CreatePathIntplLookaheadBuffer(0, 1000);
    Wmx3Lib_Adv.advMotion->ClearPathIntplLookahead(0);

    AdvMotion::PathIntplLookaheadConfiguration conf = AdvMotion::PathIntplLookaheadConfiguration();
    conf.axisCount      = 2;
    conf.axis[0]        = 0;
    conf.axis[1]        = 1;
    conf.compositeVel   = 10000;
    conf.compositeAcc   = 20000;
    conf.sampleDistance = 1000;

    Wmx3Lib_Adv.advMotion->SetPathIntplLookaheadConfiguration(0, &conf);
    AdvMotion::PathIntplLookaheadCommand path = AdvMotion::PathIntplLookaheadCommand();
    path.numPoints = 4;
    path.point[0].type = AdvMotion::PathIntplLookaheadSegmentType::Linear;
    path.point[0].data.linear.axisCount = 2;
    path.point[0].data.linear.axis[0]   = 0;
    path.point[0].data.linear.axis[1]   = 1;
    path.point[0].data.linear.target[0] = 10000;
    path.point[0].data.linear.target[1] = 0;

    path.point[1].type = AdvMotion::PathIntplLookaheadSegmentType::Linear;
    path.point[1].data.linear.axisCount = 2;
    path.point[1].data.linear.axis[0]   = 0;
    path.point[1].data.linear.axis[1]   = 1;
    path.point[1].data.linear.target[0] = 10000;
    path.point[1].data.linear.target[1] = 10000;

    path.point[2].type = AdvMotion::PathIntplLookaheadSegmentType::Linear;
    path.point[2].data.linear.axisCount = 2;
    path.point[2].data.linear.axis[0]   = 0;
    path.point[2].data.linear.axis[1]   = 1;
    path.point[2].data.linear.target[0] = 0;
    path.point[2].data.linear.target[1] = 10000;

    path.point[3].type = AdvMotion::PathIntplLookaheadSegmentType::Linear;
    path.point[3].data.linear.axisCount = 2;
    path.point[3].data.linear.axis[0]   = 0;
    path.point[3].data.linear.axis[1]   = 1;
    path.point[3].data.linear.target[0] = 0;
    path.point[3].data.linear.target[1] = 0;

    Wmx3Lib_Adv.advMotion->AddPathIntplLookaheadCommand(0, &path);

    //Execute path interpolation with look ahead
    Wmx3Lib_Adv.advMotion->StartPathIntplLookahead(0);

    //Wait until the motion is over
    Sleep(5000);

    // Stop Lookahead Buffer.
    Wmx3Lib_Adv.advMotion->StopPathIntplLookahead(0);
    // LookAhead End   --------------------------------------------------------

    Finalize();

    printf("Program End\n");
    Sleep(3000);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("LookAheadMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 1);

    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn && 
            CmStatus.axesStatus[1].servoOn   )
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    for (int i = 0; i < 2; i++)
    {
        Config::HomeParam homeParam;
        Wmx3Lib_cm.config->GetHomeParam(i, &homeParam);
        homeParam.homeType = Config::HomeType::CurrentPos;
        Wmx3Lib_cm.config->SetHomeParam(i, &homeParam);
        Wmx3Lib_cm.home->StartHome(i);
        Wmx3Lib_cm.motion->Wait(i);
    }
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 0);

    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn &&
            !CmStatus.axesStatus[1].servoOn   )
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}