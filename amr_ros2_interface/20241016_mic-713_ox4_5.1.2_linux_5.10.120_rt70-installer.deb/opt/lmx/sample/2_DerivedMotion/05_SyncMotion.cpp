/*****************************************************************************/
/* FILE        : SyncMotion.cpp                                              */
/* DESCRIPTION : Sample to operate axis synchronously.                       */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    //-----------------------------------------------------------------
    // Synchronize Master axis and Slave axis.
    // (It is impossible unless both axes are Servo On.)
    //-----------------------------------------------------------------
    Wmx3Lib_cm.sync->SetSyncMasterSlave(0, 1);

    //-----------------------------------------------------------------
    // Homing the servo to the home position.
    // (The slave axis is also homed synchronously.)
    //-----------------------------------------------------------------
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);

    //-----------------------------------------------------------------
    // Move the master axis to the specified position.
    // (The slave axis also runs synchronously.)
    //-----------------------------------------------------------------
    Motion::PosCommand posCommand       = Motion::PosCommand();
    posCommand.profile.type             = ProfileType::Trapezoidal;
    posCommand.axis                     = 0;
    posCommand.target                   = 1000000;
    posCommand.profile.velocity         = 100000;
    posCommand.profile.acc              = 1000000;
    posCommand.profile.dec              = 1000000;

    printf("Motion Start.\n");
    Wmx3Lib_cm.motion->StartMov(&posCommand);
    Wmx3Lib_cm.motion->Wait(0);

    //-------------------------------------------------------------------------
    // Release synchronization.
    //-------------------------------------------------------------------------
    Wmx3Lib_cm.sync->ResolveSync(1);

    Finalize();

    printf("Program End\n");
    Sleep(3000);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ To servo-on completion.                   */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("SyncMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 1);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn && CmStatus.axesStatus[1].servoOn)
        {
            break;
        }

        Sleep(100);
    }
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn && !CmStatus.axesStatus[1].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
