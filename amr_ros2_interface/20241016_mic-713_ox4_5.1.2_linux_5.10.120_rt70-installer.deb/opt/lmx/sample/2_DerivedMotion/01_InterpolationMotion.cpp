/*****************************************************************************/
/* FILE        : InterpolationMotion.cpp                                     */
/* DESCRIPTION : Samples that perform linear interpolation and circular      */
/*               interpolation                                               */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include <math.h>
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    Motion::LinearIntplCommand                  linearIntplCommand   = Motion::LinearIntplCommand();
    Motion::CenterAndLengthCircularIntplCommand circularIntplCommand = Motion::CenterAndLengthCircularIntplCommand();
    Motion::HelicalIntplCommand                 helicalCommand       = Motion::HelicalIntplCommand();

    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    // Homing.
    for(int i = 0; i < 3; i++)
    {
        Config::HomeParam homeParam;
        Wmx3Lib_cm.config->GetHomeParam(i, &homeParam);
        homeParam.homeType = Config::HomeType::CurrentPos;
        Wmx3Lib_cm.config->SetHomeParam(i, &homeParam);
        Wmx3Lib_cm.home->StartHome(i);
    }

    Wmx3Lib_cm.motion->Wait(0);
    Wmx3Lib_cm.motion->Wait(1);
    Wmx3Lib_cm.motion->Wait(2);

    //----------------------------------------------------------------------------
    // Select interpolation.
    //----------------------------------------------------------------------------
    printf("select interpolation.\n");
    printf("1.Linear   \n");
    printf("2.Circular \n");
    printf("3.Helical  \n");
    printf("else.End   \n");
    printf("->");
    
    int selectNum;
    while (WMX3Scanf(&selectNum, 1) != 1)
    {
        WMX3GetChar('\n');
        printf("->");
    }
    WMX3GetChar('\n');
    
    switch (selectNum)
    {
    case 1:
        printf("Linear Interpolation\n");
        linearIntplCommand.axisCount = 2;
        linearIntplCommand.axis[0]   = 0;
        linearIntplCommand.axis[1]   = 1;
        linearIntplCommand.target[0] = 100000;
        linearIntplCommand.target[1] = 200000;
    
        linearIntplCommand.profile.type             = ProfileType::Trapezoidal;
        linearIntplCommand.profile.velocity         = 100000;
        linearIntplCommand.profile.acc              = 1000000;
        linearIntplCommand.profile.dec              = 1000000;
      
        Wmx3Lib_cm.motion->StartLinearIntplPos(&linearIntplCommand);
        break;
    
    case 2:
        printf("Circular Interpolation\n");
        circularIntplCommand.axis[0]         = 0;
        circularIntplCommand.axis[1]         = 1;
        circularIntplCommand.centerPos[0]    = 100000;
        circularIntplCommand.centerPos[1]    = 200000;
        circularIntplCommand.arcLengthDegree = 360;
    
        circularIntplCommand.profile.type             = ProfileType::Trapezoidal;
        circularIntplCommand.profile.velocity         = 100000;
        circularIntplCommand.profile.acc              = 1800;
        circularIntplCommand.profile.dec              = 1800;
    
        Wmx3Lib_cm.motion->StartCircularIntplPos(&circularIntplCommand);
        break;
    
    case 3:
        printf("Helical Motion\n");
        helicalCommand.helicalProfileType = Motion::HelicalIntplProfileType::Helical;
        helicalCommand.axis[0]       = 0;       
        helicalCommand.axis[1]       = 1;       
        helicalCommand.zAxis         = 2;             
        helicalCommand.centerPos[0]     = 50000 * sqrt(2.0);  
        helicalCommand.centerPos[1]     = 50000 * sqrt(2.0);  
        helicalCommand.zEndPos          = 100000;  
        helicalCommand.clockwise        = 0;
        helicalCommand.arcLengthDegree  = 360;  
    
        helicalCommand.profile.type             = ProfileType::Trapezoidal;
        helicalCommand.profile.velocity         = 100000;
        helicalCommand.profile.acc              = 500000;
        helicalCommand.profile.dec              = 500000;
    
        Wmx3Lib_cm.motion->StartHelicalIntplPos(&helicalCommand);
        break;
    
    default:
        break;
    }

    Wmx3Lib_cm.motion->Wait(0);
    Wmx3Lib_cm.motion->Wait(1);
    Wmx3Lib_cm.motion->Wait(2);

    Finalize();

    printf("Program End\n");
    Sleep(3000);
    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ To servo-on completion.                   */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
                         DeviceType::DeviceTypeNormal,
                         INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("InterpolationMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 1);
    Wmx3Lib_cm.axisControl->SetServoOn(2, 1);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn && 
            CmStatus.axesStatus[1].servoOn &&
            CmStatus.axesStatus[2].servoOn   )
        {
            break;
        }

        Sleep(100);
    }
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    Wmx3Lib_cm.axisControl->SetServoOn(1, 0);
    Wmx3Lib_cm.axisControl->SetServoOn(2, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn &&
            !CmStatus.axesStatus[1].servoOn &&
            !CmStatus.axesStatus[2].servoOn   )
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
