/*****************************************************************************/
/* FILE        : Communication.cpp                                           */ 
/* DESCRIPTION : Sample from Device Creation to Communication Establishment  */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    WMX3Api Wmx3Lib;

    printf("Program Start.\n");

    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/", 
                         DeviceType::DeviceTypeNormal,
                         INFINITE);
    // Set Device Name.
    Wmx3Lib.SetDeviceName("Communication");

    //----------------------------------------------------------------------------
    // Start Communication.
    //----------------------------------------------------------------------------
    Wmx3Lib.StartCommunication(INFINITE);

    // Pause.
    printf("Enter Waiting\n");
    WMX3GetChar('\n');

    //----------------------------------------------------------------------------
    // Stop Communication.
    //----------------------------------------------------------------------------
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();

    printf("Program End.\n");
    Sleep(3000);

    return 0;
}
