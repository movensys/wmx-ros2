/*****************************************************************************/
/* FILE        : CreateDevice.cpp                                            */ 
/* DESCRIPTION :  Sample from Device Creation to Close.                      */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    // When all the devices are done, the WMX3 engine will also terminate.	
    WMX3Api Device;

    printf("Program Start.\n");

    // Get DevicesInfo to determine the type of device currently created
    wmx3Api::DevicesInfoA devInfo;

    // Create device.
    Device.CreateDevice("/opt/lmx/", DeviceType::DeviceTypeNormal,
                        INFINITE);

    // Set Device Name.
    Device.SetDeviceName("device");

    // Get created device state.
    Device.GetAllDevices(&devInfo);
    printf("device Id : %02d Name : %s\n",
          devInfo.devices[0].id, devInfo.devices[0].name);

    // Pause.
    printf("Enter Waiting\n");
    WMX3GetChar('\n');

    //close device.
    Device.CloseDevice();

    printf("Program End.\n");
    Sleep(3000);
 
    return 0;

}
