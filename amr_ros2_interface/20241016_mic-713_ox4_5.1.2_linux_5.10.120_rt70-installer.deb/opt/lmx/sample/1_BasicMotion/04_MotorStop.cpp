/*****************************************************************************/
/* FILE        : MotorStop.cpp                                               */
/* DESCRIPTION : Sample to stop servo by four methods                        */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    WMX3Api          Wmx3Lib;
    CoreMotionStatus CmStatus;
    CoreMotion       Wmx3Lib_cm(&Wmx3Lib);

    printf("Program Start\n");
    Sleep(1000);

    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("MotorStop");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);

    // Create a command value.
    Motion::JogCommand jogCommand = Motion::JogCommand();
    jogCommand.profile.type             = ProfileType::Trapezoidal;
    jogCommand.axis                     = 0;
    jogCommand.profile.velocity         = 100000;
    jogCommand.profile.acc              = 1000000;
    jogCommand.profile.dec              = 1000000;

    // Rotate the motor at the specified speed.
    Wmx3Lib_cm.motion->StartJog(&jogCommand);
    Sleep(3000);

    //----------------------------------------------------------------------------
    // Select the method of Motors Stop.
    //----------------------------------------------------------------------------
    printf("Please select the stop method.\n");
    printf("1.Normal Stop\n");
    printf("2.Certain time Stop(10ms)\n");
    printf("3.Quick Stop\n");
    printf("4.Deceleration Stop\n");
    printf("else. Normal Stop\n");
    printf("->");

    //----------------------------------------------------------------------------
    // Stop the axis that is operating with the "Stop" function.
    //----------------------------------------------------------------------------
    int selectNum;
    while (WMX3Scanf(&selectNum, 1) != 1)
    {
        WMX3GetChar('\n');
        printf("->");
    }

    switch (selectNum)
    {
    case 2: // Certain time Stop(10ms).
        printf("Certain time Stop(10ms).\n");
        Wmx3Lib_cm.motion->ExecTimedStop(0, 10); // 10ms 
        break;

    case 3: // Quick Stop.
        printf("Quick Stop.\n");
        Wmx3Lib_cm.motion->ExecQuickStop(0);
        break;

    case 4: // Deceleration Stop.
        printf("Deceleration Stop.\n");
        Wmx3Lib_cm.motion->Stop(0, 1000000);
        break;

    case 1: // Normal Stop.
    default:
        printf("Normal Stop.\n");
        Wmx3Lib_cm.motion->Stop(0);
        break;
    }
    
    // Wait until the axis stops.
    Wmx3Lib_cm.motion->Wait(0);

    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();

    // Pause.
    printf("Enter Waiting\n");
    WMX3GetChar('\n');

    printf("Program End\n");
    Sleep(3000);

    return 0;
}

