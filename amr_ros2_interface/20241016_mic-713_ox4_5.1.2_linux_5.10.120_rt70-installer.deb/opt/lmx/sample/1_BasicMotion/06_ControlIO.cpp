/*****************************************************************************/
/* FILE        : ControlIO.cpp                                               */
/* DESCRIPTION : Sample to read / write IO                                   */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "IOApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api Wmx3Lib;
Io      Wmx3Lib_Io(&Wmx3Lib);

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    unsigned char  inData[constants::maxIoInSize];
    unsigned char  outData[constants::maxIoOutSize];

    printf("Program Start\n");
    Sleep(1000);

    // Create device.
    Wmx3Lib.CreateDevice("/opt/lmx/",
                         DeviceType::DeviceTypeNormal,
                         INFINITE);
    // Set Device Name.
    Wmx3Lib.SetDeviceName("ControlIO");

    // Start communications.
    Wmx3Lib.StartCommunication(INFINITE);

    for (int i = 0; i < 8000; i++)
    {
        outData[i] = 0xFF;
    }

    //----------------------------------------------------------------------------
    // Execute IO Function.
    //----------------------------------------------------------------------------
    // MAX_INPUT_BUFF_SIZE  Byte Get Input  Memory Read
    printf("MAX_INPUT_BUFF_SIZE  Byte Get Input  Memory Read\n");
    Wmx3Lib_Io.GetInBytes(0x00, constants::maxIoInSize, &inData[0]);

    // MAX_OUTPUT_BUFF_SIZE Byte Set Output Memory Write
    printf("MAX_OUTPUT_BUFF_SIZE Byte Set Output Memory Write\n");
    Wmx3Lib_Io.SetOutBytes(0x00, constants::maxIoOutSize, &outData[0]);

    // MAX_OUTPUT_BUFF_SIZE Byte Get Output Memory Read
    printf("MAX_OUTPUT_BUFF_SIZE Byte Get Output Memory Read\n");
    Wmx3Lib_Io.GetOutBytes(0x00, constants::maxIoOutSize, &outData[0]);

    // 1Byte Get Input  Memory Read
    printf("1Byte Get Input  Memory Read\n");
    Wmx3Lib_Io.GetInByte(0x00, &inData[0]);

    // 1Byte Set Output Memory Write
    printf("1Byte Set Output Memory Write\n");
    Wmx3Lib_Io.SetOutByte(0x00, outData[0]);
    
    // 1Byte Get Output Memory Read
    printf("1Byte Get Output Memory Read\n");
    Wmx3Lib_Io.GetOutByte(0x00, &outData[0]);

    // 1Bit  Get Input  Memory Read
    printf("1Bit  Get Input  Memory Read\n");
    Wmx3Lib_Io.GetInBit(0x00, 0x00, &inData[0]);

    // 1Bit  Set Output Memory Write
    printf("1Bit  Set Output Memory Write\n");
    Wmx3Lib_Io.SetOutBit(0x00, 0x00, outData[0]);

    // 1Bit  Get Output Memory Read
    printf("1Bit  Get Output Memory Read\n");
    Wmx3Lib_Io.GetOutBit(0x00, 0x00, &outData[0]);

    printf("Enter Waiting...\n");
    WMX3GetChar('\n');

    // Stop Communications.
    Wmx3Lib.StopCommunication(INFINITE);

    // Discard the device.
    Wmx3Lib.CloseDevice();

    printf("Program End\n");
    Sleep(3000);

    return 0;
}
