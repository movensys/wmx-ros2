/*****************************************************************************/
/* FILE        : MotorStatus.cpp                                             */
/* DESCRIPTION : Sample to acquire servo status                              */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Define                                                                    */
/*****************************************************************************/
#define OP_STATE(state) \
    ((state == OperationState::Idle)          ? "Idle"          : \
     (state == OperationState::Pos)           ? "Pos"           : \
     (state == OperationState::Jog)           ? "Jog"           : \
     (state == OperationState::Home)          ? "Home"          : \
     (state == OperationState::Sync)          ? "Sync"          : \
     (state == OperationState::GantryHome)    ? "GantryHome"    : \
     (state == OperationState::Stop)          ? "Stop"          : \
     (state == OperationState::Intpl)         ? "Intpl"         : \
     (state == OperationState::ConstLinearVelocity) ? \
                                    "ConstLinearVelocity"       : \
     (state == OperationState::Trq)           ? "Trq"           : \
     (state == OperationState::DirectControl)       ? \
                                    "DirectControl"             : \
     (state == OperationState::PVT)           ? "PVT"           : \
     (state == OperationState::ECAM)          ? "ECAM"          : \
     (state == OperationState::SyncCatchUp)   ? "SyncCatchUp"   : \
     (state == OperationState::DancerControl) ? "DancerControl" : \
     "")

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    WMX3Api          Wmx3Lib;
    CoreMotionStatus CmStatus;
    CoreMotion       Wmx3Lib_cm(&Wmx3Lib);

    printf("Program Start\n");
    Sleep(1000);

    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("MotorStatus");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);

    // Create a command value.
    Motion::PosCommand posCommand = Motion::PosCommand();
    posCommand.profile.type             = ProfileType::Trapezoidal;
    posCommand.axis                     = 0;
    posCommand.target                   = 1000000;
    posCommand.profile.velocity         = 100000;
    posCommand.profile.acc              = 1000000;
    posCommand.profile.dec              = 1000000;

    // Rotate the motor at the specified speed.
    Wmx3Lib_cm.motion->StartMov(&posCommand);
    Wmx3Lib_cm.GetStatus(&CmStatus);

    CoreMotionAxisStatus *cmAxis;
    cmAxis = &CmStatus.axesStatus[0];

    // Dump data.
    while (cmAxis->opState != OperationState::Idle)
    {
        printf("1:status dump else:end\n");
        printf("->\n");
        int selectNum;
        while (WMX3Scanf(&selectNum, 1) != 1)
        {
            WMX3GetChar('\n');
            printf("->\n");
        }

        if (selectNum != 1)
        {
            break;
        }

        //---------------------------------------------------------------------------
        // Dump information on specified axis.
        //---------------------------------------------------------------------------
        Wmx3Lib_cm.GetStatus(&CmStatus);

        printf(" 1.PosCmd    :%-11.3f\n", cmAxis->posCmd);             // 1. PosCmd
        printf(" 2.ActPos    :%-11.3f\n", cmAxis->actualPos);          // 2. ActualPos
        printf(" 3.ActVel    :%-11.3f\n", cmAxis->actualVelocity);     // 3. ActualVelocity
        printf(" 4.ActTrq    :%-11.3f\n", cmAxis->actualTorque);       // 4. ActualTorque 
        printf(" 5.AmpAlm    :%-3d\n",    cmAxis->ampAlarm);           // 5. AmpAlarm
        printf(" 6.AmpAlmCode:0x%05x\n",  cmAxis->ampAlarmCode);       // 6. AmpAlarmCode 
        printf(" 7.SrvOn     :%-3d\n",    cmAxis->servoOn);            // 7. ServoOn
        printf(" 8.HomeDone  :%-4d\n",    cmAxis->homeDone);           // 8. HomeDone 
        printf(" 9.InPos     :%-3d\n",    cmAxis->inPos);              // 9. InPos
        printf("10.NegLS     :%-3d\n",    cmAxis->negativeLS);         // 10.negativeLS
        printf("11.PosLS     :%-3d\n",    cmAxis->positiveLS);         // 11.positiveLS
        printf("12.HomeSw    :%-4d\n",    cmAxis->homeSwitch);         // 12.homeSwitch
        printf("13.OpState   :%s\n",      OP_STATE(cmAxis->opState));  // 13.OperationState

        Sleep(1000);
    }

    // Motor stop.
    Wmx3Lib_cm.motion->ExecQuickStop(0);

    // Wait until the axis stops.
    Wmx3Lib_cm.motion->Wait(0);

    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();

    printf("Program End\n");
    Sleep(3000);

    return 0;
}
