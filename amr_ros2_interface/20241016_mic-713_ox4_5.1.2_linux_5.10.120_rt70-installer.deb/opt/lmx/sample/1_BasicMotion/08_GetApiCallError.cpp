/*****************************************************************************/
/* FILE        : GetApiCallError.cpp                                         */
/* DESCRIPTION : Sample to intentionally generate an error and check the     */ 
/*               API error.                                                  */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    char      errString[256];
    int       apiCallError;

    WMX3Api          Wmx3Lib;
    CoreMotion       Wmx3Lib_cm(&Wmx3Lib);
    CoreMotionStatus CmStatus;

    printf("Program Start\n");
    Sleep(1000);

    // Create device.
    Wmx3Lib.CreateDevice("/opt/lmx/", 
                         DeviceType::DeviceTypeNormal,
                         INFINITE);
    // Set Device Name.
    Wmx3Lib.SetDeviceName("GetApiCallError");

    // ------------------------------------------------------------------------
    // StartCommunication is not performed to intentionally generate an error.
    // ------------------------------------------------------------------------
#if 0
    // Start communications.
    Wmx3Lib.StartCommunication(INFINITE);

#endif

    // Confirm error when "Servo On" when communication is not possible.
    apiCallError = Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    if(apiCallError != ErrorCode::None)
    {
        Wmx3Lib_cm.ErrorToString(apiCallError, errString, 256);
        printf("SetServoOn Failed! [0x%x : %s]\n", 
               apiCallError, errString);

        printf("Discard the device after entering the key\n");
        WMX3GetChar('\n');

        Wmx3Lib.CloseDevice();
        printf("Program End\n");
        Sleep(3000);
        return 1;
    }

    printf("Discard the device after entering the key\n");
    WMX3GetChar('\n');

    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();

    printf("Program End\n");
    Sleep(3000);

    return 0;
}
