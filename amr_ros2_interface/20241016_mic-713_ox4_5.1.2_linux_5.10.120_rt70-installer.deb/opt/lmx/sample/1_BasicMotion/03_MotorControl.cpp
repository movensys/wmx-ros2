/*****************************************************************************/
/* FILE        : MotorControl.cpp                                            */ 
/* DESCRIPTION : Sample from device creation to motor operation to device    */
/*               close                                                       */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    WMX3Api          Wmx3Lib;
    CoreMotionStatus CmStatus;
    CoreMotion       Wmx3Lib_cm(&Wmx3Lib);

    printf("Program Start\n");
    Sleep(1000);

    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
                         DeviceType::DeviceTypeNormal,
                         INFINITE);
    // Set Device Name.
    Wmx3Lib.SetDeviceName("MotorControl");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);

    //----------------------------------------------------------------------------
    // Create a command value.
    //----------------------------------------------------------------------------
    Motion::PosCommand posCommand = Motion::PosCommand();
    posCommand.profile.type             = ProfileType::Trapezoidal;
    posCommand.axis                     = 0;
    posCommand.target                   = 1000000;
    posCommand.profile.velocity         = 100000;
    posCommand.profile.acc              = 1000000;
    posCommand.profile.dec              = 1000000;

    //----------------------------------------------------------------------------
    // Execute command to move from current position to specified position.
    //----------------------------------------------------------------------------
    Wmx3Lib_cm.motion->StartMov(&posCommand);

    //----------------------------------------------------------------------------
    // Wait until the axis moves to the target position and stops.
    //----------------------------------------------------------------------------
    Wmx3Lib_cm.motion->Wait(0);

    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();

    printf("Program End\n");
    Sleep(3000);

    return 0;
}
