/*****************************************************************************/
/* FILE        : JerkRatioMotion.cpp                                         */
/* DESCRIPTION : Sample to change the jerk ratio and operate the servo       */
/*****************************************************************************/

/*****************************************************************************/
/* Header                                                                    */
/*****************************************************************************/
#include "WMX3Api.h"
#include "CoreMotionApi.h"
#include "WMX3Funcs.h"

/*****************************************************************************/
/* Name Space                                                                */
/*****************************************************************************/
using namespace wmx3Api;
using namespace std;

/*****************************************************************************/
/* Global valiables                                                          */
/*****************************************************************************/
WMX3Api          Wmx3Lib;
CoreMotionStatus CmStatus;
CoreMotion       Wmx3Lib_cm(&Wmx3Lib);

/*****************************************************************************/
/* Prototype declaration                                                     */
/*****************************************************************************/
void Initialize();
void Finalize();

/*****************************************************************************/
/* Function                                                                  */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Function    : _tmain                                                      */
/* Description : Main Function.                                              */
/*---------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
    double jerkRatio;

    printf("Program Start\n");
    Sleep(1000);

    Initialize();

    //----------------------------------------------------------------------------
    // Select jerkratio.
    //----------------------------------------------------------------------------
    printf("select jerkratio.\n");
    printf("1.jerkratio   :0   percent.\n");
    printf("2.jerkratio   :25  percent.\n");
    printf("3.jerkratio   :50  percent.\n");
    printf("4.jerkratio   :75  percent.\n");
    printf("5.jerkratio   :100 percent.\n");
    printf("else.jerkratio:0   percent.\n");
    printf("->");

    int selectNum;
    while (WMX3Scanf(&selectNum, 1) != 1)
    {
        WMX3GetChar('\n');
        printf("->");
    }
    WMX3GetChar('\n');

    switch (selectNum)
    {
    case 2:
        printf("jerkratio:25 percent.\n");
        jerkRatio = 0.25;
        break;
    case 3:
        printf("jerkratio:50 percent.\n");
        jerkRatio = 0.50;
        break;
    case 4:
        printf("jerkratio:75 percent.\n");
        jerkRatio = 0.75;
        break;
    case 5:
        printf("jerkratio:100 percent.\n");
        jerkRatio = 1.00;
        break;
    case 1:
    default:
        printf("jerkratio:0 percent.\n");
        jerkRatio = 0;
        break;
    }

    printf("Motion Start!\n");

    // Create a command value.
    Motion::PosCommand posCommand = Motion::PosCommand();
    posCommand.profile.type             = ProfileType::JerkRatio;
    posCommand.axis                     = 0;
    posCommand.target                   = 1000000;
    posCommand.profile.velocity         = 100000;
    posCommand.profile.startingVelocity = 0;
    posCommand.profile.endVelocity      = 0;
    posCommand.profile.acc              = 1000000;
    posCommand.profile.dec              = 1000000;
    posCommand.profile.jerkAccRatio     = jerkRatio;
    posCommand.profile.jerkDecRatio     = jerkRatio;

    // Rotate the motor at the specified speed.
    Wmx3Lib_cm.motion->StartMov(&posCommand);

    //Wait for axis movement to finish
    Wmx3Lib_cm.motion->Wait(0);

    Finalize();

    printf("Program End\n");
    Sleep(3000);

    return 0;
}

/*---------------------------------------------------------------------------*/
/* Function    : Initialize                                                  */
/* Description : Device creation ~ Run until Homing.                         */
/*---------------------------------------------------------------------------*/
void Initialize()
{
    // Create devices.
    Wmx3Lib.CreateDevice("/opt/lmx/",
        DeviceType::DeviceTypeNormal,
        INFINITE);

    // Set Device Name.
    Wmx3Lib.SetDeviceName("JerkRatioMotion");

    // Start Communication.
    Wmx3Lib.StartCommunication(INFINITE);

    // Set servo on.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 1);

    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Homing.
    Config::HomeParam homeParam;
    Wmx3Lib_cm.config->GetHomeParam(0, &homeParam);
    homeParam.homeType = Config::HomeType::CurrentPos;
    Wmx3Lib_cm.config->SetHomeParam(0, &homeParam);
    Wmx3Lib_cm.home->StartHome(0);
    Wmx3Lib_cm.motion->Wait(0);
}

/*---------------------------------------------------------------------------*/
/* Function    : Finalize                                                    */
/* Description : It executes from servo OFF to device close.                 */
/*---------------------------------------------------------------------------*/
void Finalize()
{
    // Set servo off.
    Wmx3Lib_cm.axisControl->SetServoOn(0, 0);
    while (true)
    {
        Wmx3Lib_cm.GetStatus(&CmStatus);
        if (!CmStatus.axesStatus[0].servoOn)
        {
            break;
        }

        Sleep(100);
    }

    // Stop Communication.
    Wmx3Lib.StopCommunication(INFINITE);

    //close device.
    Wmx3Lib.CloseDevice();
}
